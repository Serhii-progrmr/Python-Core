# Абсолютний імпорт
# from my_package.foo import foo
# from my_package.baz.operation import mul, sum
# from my_package.bar.info import log

# Відносний імпорт
from .foo import foo
from .baz.operation import mul, sum
from .bar.info import log, foo as log_foo


__all__ = ['foo', 'mul', 'sum']
