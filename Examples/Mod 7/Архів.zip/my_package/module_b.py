import module_a

def bar():
    print('Функція bar з модуля "b"')


if __name__ == "__main__":
    bar()