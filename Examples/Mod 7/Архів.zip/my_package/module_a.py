import module_b

def foo():
    print('Функція foo з модуля "а"')


def temporary():
    import module_b
    module_b.bar()


if __name__ == '__main__':
    foo()
    # module_b.bar()
    temporary()
