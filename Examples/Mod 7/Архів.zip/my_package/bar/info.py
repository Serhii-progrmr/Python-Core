def log(message: str) -> None:
    print(f'Logging: {message}')


def foo() -> str:
    return 'Your code is ugly'
