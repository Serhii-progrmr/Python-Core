def sum(a: int, b: int) -> int:
    return a + b


def mul(a: int, b: int) -> int:
    return a * b
