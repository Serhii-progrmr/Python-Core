from my_package import *


def mul(a: int) -> int:
    b = 5
    c = [3, 5]
    return a * 3

import shutil


def handle_arhive(filename: Path, target_folder: Path) -> None:
    target_folder.mkdir(exist_ok=True, parents=True)
    folder_for_file = target_folder / normalize(filename.name.replace(filename.suffix, ''))
    print(folder_for_file)
    folder_for_file.mkdir(exist_ok=True, parents=True)
    try:

        shutil.unpack_archive(str(filename.resolve()),
                              str(folder_for_file.resolve()))
    except shutil.ReadError:
        folder_for_file.rmdir()
        return None
    filename.unlink()
if __name__ == "__main__":
    ar_file = shutil.make_archive('test', 'tar', 'my_package')
    print(ar_file)
    print(type(ar_file))
    shutil.unpack_archive(ar_file, 'Test')

    print(foo('Petro'))  # foo from foo.py
    # print(mul(5, 3))
    print(mul(8))
    print(sum(15, 11))
    # print(log_foo())  # foo from info.py
    # log('Begin')

# Hello Alex
# Hello Petro
# 24
# 26