# Логічні операції

class Car:
    store_name = 'GoIT'

    def __init__(self, year, mark, model, color, price):
        self.year = year
        self.mark = mark
        self.model = model
        self.color = color
        self.price = price

    def __str__(self):
        return f'{self.store_name}: {self.mark}.{self.model}: {self.year}, {self.color}, {self.price}'

    def __eq__(self, other):
        print('__eq__ called')
        return self.price == other.price

    def __ne__(self, other):
        print('__ne__ called')
        return self.price != other.price

    def __lt__(self, other):
        print('__lt__ called')
        return self.price < other.price

    def __le__(self, other):
        print('__le__ called')
        return self.price <= other.price

    def __gt__(self, other):
        print('__gt__ called')
        return self.price > other.price

    def __ge__(self, other):
        print('__ge__ called')
        return self.price >= other.price


car_1 = Car(2019, 'Tesla', 'model X', 'White', 5500)
car_2 = Car(2023, 'Ford', 'Fusion', 'Black', 6500)
print(car_1 == car_2)
print(car_1 != car_2)
print(car_1 < car_2)
print(car_1 > car_2)
print(car_1 <= car_2)
print(car_1 >= car_2)
