"""
Розбираємо різницю між: звичайним методом, @classmethod и @staticmethod
"""


class DecoratorTest:

    def doubler(self, x):
        print(self)
        print('Mul on 2')
        return x * 2

    @classmethod
    def triples(cls, x):
        print('Mul on 3')
        return x * 3

    @staticmethod
    def quad(x):
        print('Mul on 4')
        return x * 4


decor = DecoratorTest()
print('---Екземпляр класу---')
print(decor.doubler(4))
print(decor.triples(4))
print(decor.quad(4))
print('---Виклик через клас---')
print(DecoratorTest.triples(4))  # звертаємось через клас завдяки @classmethod
print(DecoratorTest.quad(4))  # звертаємось через клас завдяки @staticmethod
print(DecoratorTest.doubler(4))  # неможемо звернутись