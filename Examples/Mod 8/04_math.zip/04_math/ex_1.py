import math
a = math.log(23.5) + math.sin(45) - math.sqrt(49)
print(a)