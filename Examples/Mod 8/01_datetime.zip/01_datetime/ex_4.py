from datetime import datetime
print(datetime.now().timestamp())
print(datetime.now().toordinal())

